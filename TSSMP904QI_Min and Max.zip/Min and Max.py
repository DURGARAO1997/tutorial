list_1=[54,546,548,60]

max_result=max(list_1)

min_result=min(list_1)

print(max_result, min_result)