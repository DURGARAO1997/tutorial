num=int(input())
if num>1:
    for n in range(2,num):
        if num%2==0:
            print('NO')
            break
    else:
        print("YES")