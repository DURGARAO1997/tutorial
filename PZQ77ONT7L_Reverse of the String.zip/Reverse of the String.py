Input=input()
reverse_string=Input[::-1]
print(reverse_string)