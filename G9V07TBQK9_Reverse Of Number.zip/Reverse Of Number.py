def reverse_number(N):
    reversed_str = str(N)[::-1]
    reversed_str = reversed_str.strip('0')
    reversed_num = int(reversed_str)

    return reversed_num

N = input()
reversed_N = reverse_number(N)
print(reversed_N)